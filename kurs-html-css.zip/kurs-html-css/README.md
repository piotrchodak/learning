# Kurs HTML/CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/PiotrChodak/pen/OJwyeoJ](https://codepen.io/PiotrChodak/pen/OJwyeoJ).

